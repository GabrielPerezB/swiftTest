//
//  product.swift
//  CustomizedCell
//
//  Created by Administrador on 28/9/16.
//  Copyright © 2016 GabrielP_kevinA. All rights reserved.
//

import Foundation

struct Product {
    
    var name : String
    var description: String
    var price: Int
    
}