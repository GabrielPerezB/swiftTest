//
//  User.swift
//  CocoaPodsExample
//
//  Created by Administrador on 21/9/16.
//  Copyright © 2016 GabrielP. All rights reserved.
//

import Foundation

struct User {
    var id: Int
    var name: String
}