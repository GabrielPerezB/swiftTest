//
//  Constants.swift
//  CocoaPodsExample
//
//  Created by Administrador on 21/9/16.
//  Copyright © 2016 GabrielP. All rights reserved.
//

import Foundation
class Constants {
    //URLs
    static let BASE_URL: String = "https://jsonplaceholder.typicode.com/"
    static let USERS_URL: String = "/users"
    
    //Titles
    static let USER_TITLE: String = "USER"
}