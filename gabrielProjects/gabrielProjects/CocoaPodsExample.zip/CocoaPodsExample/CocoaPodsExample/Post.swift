//
//  Post.swift
//  CocoaPodsExample
//
//  Created by Administrador on 21/9/16.
//  Copyright © 2016 GabrielP. All rights reserved.
//

import Foundation

struct Post {
    var id: Int
    var title: String
    var body: String
}