//
//  Photo.swift
//  AlbumWS
//
//  Created by Estudiante on 9/9/16.
//  Copyright © 2016 Tecnologico de Costa Rica. All rights reserved.
//

import Foundation

struct Photo{
    
    var title : String
    var url : String
}