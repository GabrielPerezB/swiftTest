//
//  Album.swift
//  AlbumWS
//
//  Created by Estudiante on 7/9/16.
//  Copyright © 2016 Tecnologico de Costa Rica. All rights reserved.
//

import Foundation


struct Album {
    
    var id : Int
    var title : String
    
}